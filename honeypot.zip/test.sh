 
func() {
	    echo "Usage:"
	        echo "test.sh [-j S_DIR] [-m D_DIR]"
		    echo "Description:"
		        echo "S_DIR,the path of source."
			    echo "D_DIR,the path of destination."
			        exit -1
			}
			 
			upload="false"
			 
			while getopts 'h:j:m:u' OPT; do
				    case $OPT in
					            j) S_DIR="$OPTARG";;
						            m) D_DIR="$OPTARG";;
							            u) upload="true";;
								            h) func;;
									            ?) func;;
										        esac
										done
										 
										echo $S_DIR
										echo $D_DIR
										echo $upload
